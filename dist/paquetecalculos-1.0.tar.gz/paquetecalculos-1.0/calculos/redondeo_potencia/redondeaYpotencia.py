def potencia(base,exponente):
	print("La potencia es: ", base**exponente)

def redondear(numero):
	print("El redondeo es: ", round(numero))
